<ul class="nav flex-column sticky-top pl-0">
    <?php echo sp_render_sidebar_menu(); ?>
</ul>
